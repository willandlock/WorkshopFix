package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysftpserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysftpserverApplication.class, args);
		while(true);
	}

}
