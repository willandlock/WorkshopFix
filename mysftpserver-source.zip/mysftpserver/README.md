# Getting Started

Helpful URLs for creating this
https://programmingtechie.com/2019/02/23/sftp-server-java-springboot/
https://java.tutorialink.com/how-to-execute-remote-commands-using-apache-mina-sshd/

How to run it 
cd C:\Users\willa\Documents\workspace-spring-tool-suite-4-4.12.0.RELEASE\mysftpserver\target>

C:\Users\willa\myapps\jdk-11.0.12\bin\java.exe -jar mysftpserver-0.0.1-SNAPSHOT.jar
